import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";

export default function RegistroVisitantes() {
  const [visitantes, setVisitantes] = useState([]);
  const [formulario, setFormulario] = useState({
    nombre: "",
    carrera: "",
    motivo: "",
  });
  const [busqueda, setBusqueda] = useState("");

  useEffect(() => {
    const data = localStorage.getItem("visitantes");
    if (data) setVisitantes(JSON.parse(data));
  }, []);

  useEffect(() => {
    localStorage.setItem("visitantes", JSON.stringify(visitantes));
  }, [visitantes]);

  const handleChange = (e) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formulario.nombre || !formulario.carrera || !formulario.motivo) return;
    const nuevoVisitante = {
      ...formulario,
      hora: new Date().toLocaleTimeString(),
      id: Date.now(),
    };
    setVisitantes([nuevoVisitante, ...visitantes]);
    setFormulario({ nombre: "", carrera: "", motivo: "" });
  };

  const filtrarVisitantes = visitantes.filter((v) =>
    v.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
    v.carrera.toLowerCase().includes(busqueda.toLowerCase()) ||
    v.motivo.toLowerCase().includes(busqueda.toLowerCase())
  );

  const exportarExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(visitantes);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Visitantes");
    XLSX.writeFile(workbook, "registro_visitantes.xlsx");
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Registro de Visitantes - Biblioteca</h1>
      <form onSubmit={handleSubmit} className="space-y-3 mb-6">
        <input
          type="text"
          name="nombre"
          placeholder="Nombre"
          value={formulario.nombre}
          onChange={handleChange}
          className="w-full border p-2 rounded"
        />
        <input
          type="text"
          name="carrera"
          placeholder="Carrera"
          value={formulario.carrera}
          onChange={handleChange}
          className="w-full border p-2 rounded"
        />
        <input
          type="text"
          name="motivo"
          placeholder="Motivo de la visita"
          value={formulario.motivo}
          onChange={handleChange}
          className="w-full border p-2 rounded"
        />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">
          Registrar entrada
        </button>
      </form>

      <input
        type="text"
        placeholder="Buscar por nombre, carrera o motivo..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
        className="w-full border p-2 rounded mb-4"
      />

      <button
        onClick={exportarExcel}
        className="mb-4 bg-green-600 text-white px-4 py-2 rounded"
      >
        Exportar a Excel
      </button>

      <ul className="space-y-2">
        {filtrarVisitantes.map((v) => (
          <li key={v.id} className="border p-3 rounded shadow-sm">
            <p><strong>Nombre:</strong> {v.nombre}</p>
            <p><strong>Carrera:</strong> {v.carrera}</p>
            <p><strong>Motivo:</strong> {v.motivo}</p>
            <p><strong>Hora:</strong> {v.hora}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
